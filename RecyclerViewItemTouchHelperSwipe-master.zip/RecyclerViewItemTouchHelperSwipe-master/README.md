# RecyclerViewItemTouchHelperSwipe
RecyclerViewItemTouchHelperSwipe


<h1> Swipe  To Delete</h1>
![Alt text](http://tutorialsbuzz.com/wp-content/uploads/2016/12/giphy.gif?raw=true "Optional Title")


<h1> Undo Swipe Delete </h1>
![Alt text](http://tutorialsbuzz.com/wp-content/uploads/2016/12/undoSwipe.gif?raw=true "Optional Title")


<h1 style="font-size:72px;">Video</h1> 

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/Fb-1aGNUPqY/0.jpg)](https://www.youtube.com/watch?v=Fb-1aGNUPqY)

Read More : http://tutorialsbuzz.com/2016/12/android-swipe-recyclerview-items-using-itemtouchhelper.html
